import { Command, flags } from '@oclif/command';
export default class Clean extends Command {
    static description: string;
    static args: {
        name: string;
    }[];
    static flags: {
        format: flags.IOptionFlag<string>;
    };
    binDir: any;
    format: any;
    prefix: any;
    run(): Promise<void>;
    clean(file: any): void;
    files(): Promise<any[]>;
}
