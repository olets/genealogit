import { Command, flags } from '@oclif/command';
export default class Build extends Command {
    static args: {
        name: string;
    }[];
    static flags: {
        format: flags.IOptionFlag<string>;
        verbose: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static description: string;
    connectProgress: any;
    binDir: any;
    format: any;
    individuals: any;
    prefix: any;
    progress: any;
    verbose: any;
    run(): Promise<void>;
    files(): Promise<any[]>;
    build(file: any): void;
    individualName(individual: any): any;
    clean(): void;
    create(individual: any): void;
    connectToParents(individual: any): void;
}
