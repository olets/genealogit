export declare function projectPath(path?: string): string;
